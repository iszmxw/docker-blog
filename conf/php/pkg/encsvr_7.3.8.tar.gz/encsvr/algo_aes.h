#ifndef ALGO_AES_H
#define ALGO_AES_H

#include <openssl/evp.h>

#define AES_256_CBC  1


int _encrypt(unsigned char *plaintext, int plaintext_len, unsigned char *key, unsigned char *iv, const EVP_CIPHER *type, unsigned char *ciphertext);
int _decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key, unsigned char *iv, const EVP_CIPHER *type, unsigned char *plaintext);

int EnAES256(unsigned char *plaintext, int plaintext_len, unsigned char *ciphertext, int mode);
int DeAES256(unsigned char *ciphertext, int ciphertext_len, unsigned char *plaintext, int mode);

#endif