/*
  +----------------------------------------------------------------------+
  | PHP Version 7                                                        |
  +----------------------------------------------------------------------+
  | Copyright (c) 1997-2017 The PHP Group                                |
  +----------------------------------------------------------------------+
  | This source file is subject to version 3.01 of the PHP license,      |
  | that is bundled with this package in the file LICENSE, and is        |
  | available through the world-wide-web at the following url:           |
  | http://www.php.net/license/3_01.txt                                  |
  | If you did not receive a copy of the PHP license and are unable to   |
  | obtain it through the world-wide-web, please send a note to          |
  | license@php.net so we can mail you a copy immediately.               |
  +----------------------------------------------------------------------+
  | Author:                                                              |
  +----------------------------------------------------------------------+
*/

/* $Id$ */

#ifdef HAVE_CONFIG_H
#include "config.h"
#endif

#include "php.h"
#include "php_ini.h"
#include "ext/standard/info.h"
#include "php_encsvr.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <openssl/aes.h>
#include <openssl/evp.h>
/* If you declare any globals in php_encsvr.h uncomment this:
ZEND_DECLARE_MODULE_GLOBALS(encsvr)
*/
#define AES_256_CBC     1
/* True global resources - no need for thread safety here */
static int le_encsvr;


char *base64_encode(const unsigned char *value, int vlen, char *result);
unsigned char *base64_decode(const char *value, unsigned char *result, int *rlen);
int _encrypt(unsigned char *plaintext, int plaintext_len, unsigned char *key, unsigned char *iv, const EVP_CIPHER *type, unsigned char *ciphertext);
int _decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key, unsigned char *iv, const EVP_CIPHER *type, unsigned char *plaintext);

int EnAES256(unsigned char *plaintext, int plaintext_len, unsigned char *ciphertext, int mode);
int DeAES256(unsigned char *ciphertext, int ciphertext_len, unsigned char *plaintext, int mode);


/* {{{ PHP_INI
 */
/* Remove comments and fill if you need to have entries in php.ini
PHP_INI_BEGIN()
    STD_PHP_INI_ENTRY("encsvr.global_value",      "42", PHP_INI_ALL, OnUpdateLong, global_value, zend_encsvr_globals, encsvr_globals)
    STD_PHP_INI_ENTRY("encsvr.global_string", "foobar", PHP_INI_ALL, OnUpdateString, global_string, zend_encsvr_globals, encsvr_globals)
PHP_INI_END()
*/
/* }}} */

/* Remove the following function when you have successfully modified config.m4
   so that your module can be compiled into PHP, it exists only for testing
   purposes. */

/* Every user-visible function in PHP should document itself in the source */
/* {{{ proto string confirm_encsvr_compiled(string arg)
   Return a string to confirm that the module is compiled in */
PHP_FUNCTION(confirm_encsvr_compiled)
{
	char *arg = NULL;
	size_t arg_len, len;
	zend_string *strg;

	if (zend_parse_parameters(ZEND_NUM_ARGS(), "s", &arg, &arg_len) == FAILURE) {
		return;
	}

	strg = strpprintf(0, "Congratulations! You have successfully modified ext/%.78s/config.m4. Module %.78s is now compiled into PHP.", "encsvr", arg);

	RETURN_STR(strg);
}
/* }}} */
/* The previous line is meant for vim and emacs, so it can correctly fold and
   unfold functions in source code. See the corresponding marks just before
   function definition, where the functions purpose is also documented. Please
   follow this convention for the convenience of others editing your code.
*/


/* {{{ php_encsvr_init_globals
 */
/* Uncomment this function if you have INI entries
static void php_encsvr_init_globals(zend_encsvr_globals *encsvr_globals)
{
	encsvr_globals->global_value = 0;
	encsvr_globals->global_string = NULL;
}
*/
/* }}} */

/* {{{ PHP_MINIT_FUNCTION
 */
PHP_MINIT_FUNCTION(encsvr)
{
	/* If you have INI entries, uncomment these lines
	REGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MSHUTDOWN_FUNCTION
 */
PHP_MSHUTDOWN_FUNCTION(encsvr)
{
	/* uncomment this line if you have INI entries
	UNREGISTER_INI_ENTRIES();
	*/
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request start */
/* {{{ PHP_RINIT_FUNCTION
 */
PHP_RINIT_FUNCTION(encsvr)
{
#if defined(COMPILE_DL_ENCSVR) && defined(ZTS)
	ZEND_TSRMLS_CACHE_UPDATE();
#endif
	return SUCCESS;
}
/* }}} */

/* Remove if there's nothing to do at request end */
/* {{{ PHP_RSHUTDOWN_FUNCTION
 */
PHP_RSHUTDOWN_FUNCTION(encsvr)
{
	return SUCCESS;
}
/* }}} */

/* {{{ PHP_MINFO_FUNCTION
 */
PHP_MINFO_FUNCTION(encsvr)
{
	php_info_print_table_start();
	php_info_print_table_header(2, "encsvr support", "enabled");
	php_info_print_table_end();

	/* Remove comments if you have entries in php.ini
	DISPLAY_INI_ENTRIES();
	*/
}
/* }}} */

/* {{{ encsvr_functions[]
 *
 * Every user visible function must have an entry in encsvr_functions[].
 */
const zend_function_entry encsvr_functions[] = {
	PHP_FE(confirm_encsvr_compiled,	NULL)		/* For testing, remove later. */
	PHP_FE(x_encrypt,	NULL)
	PHP_FE(x_decrypt,	NULL)
	PHP_FE_END	/* Must be the last line in encsvr_functions[] */
};
/* }}} */

/* {{{ encsvr_module_entry
 */
zend_module_entry encsvr_module_entry = {
	STANDARD_MODULE_HEADER,
	"encsvr",
	encsvr_functions,
	PHP_MINIT(encsvr),
	PHP_MSHUTDOWN(encsvr),
	PHP_RINIT(encsvr),		/* Replace with NULL if there's nothing to do at request start */
	PHP_RSHUTDOWN(encsvr),	/* Replace with NULL if there's nothing to do at request end */
	PHP_MINFO(encsvr),
	PHP_ENCSVR_VERSION,
	STANDARD_MODULE_PROPERTIES
};
/* }}} */



/* {{{ proto string x_encrypt(string s)
    */
PHP_FUNCTION(x_encrypt)
{
	char *s = NULL;
	int argc = ZEND_NUM_ARGS();
	int s_len;
    char out[8192] = {0};
    int ret_len = -1;


    ZEND_PARSE_PARAMETERS_START(1, 2)
        Z_PARAM_STRING(s,s_len)
    ZEND_PARSE_PARAMETERS_END();
        
    ret_len = EnAES256(s, s_len, out, 1);
    if (ret_len <= 0) 
        RETURN_NULL();
    //outlen walt
	int outLen = strlen(out);
    RETURN_STRINGL(out, outLen);
}
/* }}} */

/* {{{ proto string x_decrypt(string s)
    */
PHP_FUNCTION(x_decrypt)
{
    char *s;
	int argc = ZEND_NUM_ARGS();
	int s_len;
    char out[8192] = {0};
    int ret_len = -1;

    ZEND_PARSE_PARAMETERS_START(1, 1)
        Z_PARAM_STRING(s,s_len)
    ZEND_PARSE_PARAMETERS_END();
    
    ret_len = DeAES256(s, s_len, out, 1);
    if (ret_len <= 0) 
        RETURN_NULL();

    RETURN_STRINGL(out, strlen(out));
}
/* }}} */

/* {{{ proto string x_encrypt(string s, int flag)
    */
PHP_FUNCTION(x_encrypt0)
{
	char *s;
	int argc = ZEND_NUM_ARGS();
	int s_len;
	long flag;
    char out[4096] = {0};
    int ret_len = -1;

	if (zend_parse_parameters(argc TSRMLS_CC, "sl", &s, &s_len, &flag) == FAILURE) 
		return;

    if (flag == 1)
    {
        ret_len = EnAES256(s, s_len, out, 1);
    }
    else if (flag == 0)
    {
        ret_len = DeAES256(s, s_len, out, 1);
    }
    
    if (ret_len <= 0) 
        RETURN_NULL();

    RETURN_STRINGL(out, strlen(out));
}
#ifdef COMPILE_DL_ENCSVR
#ifdef ZTS
ZEND_TSRMLS_CACHE_DEFINE()
#endif
ZEND_GET_MODULE(encsvr)
#endif
/*
 * Local variables:
 * tab-width: 4
 * c-basic-offset: 4
 * End:
 * vim600: noet sw=4 ts=4 fdm=marker
 * vim<600: noet sw=4 ts=4
 */
// base64 tables
static char basis_64[] = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/";
static signed char index_64[128] =
{
    -1,-1,-1,-1, -1,-1,-1,-1, -1,-1,-1,-1, -1,-1,-1,-1,
    -1,-1,-1,-1, -1,-1,-1,-1, -1,-1,-1,-1, -1,-1,-1,-1,
    -1,-1,-1,-1, -1,-1,-1,-1, -1,-1,-1,62, -1,-1,-1,63,
    52,53,54,55, 56,57,58,59, 60,61,-1,-1, -1,-1,-1,-1,
    -1, 0, 1, 2,  3, 4, 5, 6,  7, 8, 9,10, 11,12,13,14,
    15,16,17,18, 19,20,21,22, 23,24,25,-1, -1,-1,-1,-1,
    -1,26,27,28, 29,30,31,32, 33,34,35,36, 37,38,39,40,
    41,42,43,44, 45,46,47,48, 49,50,51,-1, -1,-1,-1,-1
};

#define CHAR64(c)  (((c) < 0 || (c) > 127) ? -1 : index_64[(c)])


/*
 * value, will encode string
 * vlen, the length of value
 * result, the out buffer of size (vlen * 4) / 3 + 5, make sure enought space
 * return, the result
 *
 * char *base64_encode(const unsigned char *value, int vlen, char *result)
 *
 */
char *base64_encode(const unsigned char *value, int vlen, char *result)
{
    unsigned char oval = 0;
    //char *result = (char *)malloc((vlen * 4) / 3 + 5);
    char *out = result;

    // 0x30 -> 00110000
    // 0x3C -> 00111100
    // 0x3F -> 00111111
    while (vlen >= 3)
    {
        *out++ = basis_64[value[0] >> 2];
        *out++ = basis_64[((value[0] << 4) & 0x30) | (value[1] >> 4)];
        *out++ = basis_64[((value[1] << 2) & 0x3C) | (value[2] >> 6)];
        *out++ = basis_64[value[2] & 0x3F];
        value += 3;
        vlen -= 3;
    }
    if (vlen > 0)
    {
        *out++ = basis_64[value[0] >> 2];
        oval = (value[0] << 4) & 0x30;
        if (vlen > 1) oval |= value[1] >> 4;
        *out++ = basis_64[oval];
        *out++ = (vlen < 2) ? '=' : basis_64[(value[1] << 2) & 0x3C];
        *out++ = '=';
    }
    *out = '\0';
    return result;
}

/*
 * value, will decode string
 * result, the out buffer of size (vlen * 3) / 4 + 1, make sure enought space
 * rlen, the length of result
 * return, the result
 *
 * unsigned char *base64_decode(const char *value, unsigned char *result, int *rlen)
 *
 */
unsigned char *base64_decode(const char *value, unsigned char *result, int *rlen)
{
    int c1, c2, c3, c4;
    //int vlen = strlen(value);
    //unsigned char *result =(unsigned char *)malloc((vlen * 3) / 4 + 1);
    unsigned char *out = result;

    *rlen = 0;

    // 0xFC -> 11111100
    // 0x03 -> 00000011
    // 0xF0 -> 11110000
    // 0x0F -> 00001111
    // 0xC0 -> 11000000
    while (1)
    {
        if (value[0]==0)
        {
            *out = '\0';
            return result;
        }
        c1 = value[0];
        if (CHAR64(c1) == -1) goto base64_decode_error;
        c2 = value[1];
        if (CHAR64(c2) == -1) goto base64_decode_error;
        c3 = value[2];
        if ((c3 != '=') && (CHAR64(c3) == -1)) goto base64_decode_error;
        c4 = value[3];
        if ((c4 != '=') && (CHAR64(c4) == -1)) goto base64_decode_error;
        value += 4;
        *out++ = (CHAR64(c1) << 2) | (CHAR64(c2) >> 4);
        *rlen += 1;
        if (c3 != '=')
        {
            *out++ = ((CHAR64(c2) << 4) & 0xf0) | (CHAR64(c3) >> 2);
            *rlen += 1;
            if (c4 != '=')
            {
                *out++ = ((CHAR64(c3) << 6) & 0xc0) | CHAR64(c4);
                *rlen += 1;
            }
        }
    }
base64_decode_error:
    *result = 0;
    *rlen = 0;
    return result;
}


unsigned char *key256 = (unsigned char *)"\xF2\x2C\xE1\xB3\xFB\x40\x90\xCB\x1C\x12\xE6\x51\x95\xA3\xF7\xEB\xD4\xF8\x83\x0D\x31\x52\xF7\xDA\x6B\x47\x3A\x80\xFC\x29\x88\x46";
unsigned char *ive128 = (unsigned char *)"\xCE\x99\x70\x93\xA8\x6C\xF3\x2E\xE2\x2A\xA4\x78\x34\x86\xF9\xA9";

#if 1
#define handleErrors(s) {\
  printf("[%s:%d]:%s\n", __FUNCTION__, __LINE__, #s);\
  return -1;\
}
#else
#define handleErrors(s) {return -1;}
#endif


int _encrypt(unsigned char *plaintext, int plaintext_len, unsigned char *key, unsigned char *iv, const EVP_CIPHER *type, unsigned char *ciphertext);
int _decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key, unsigned char *iv, const EVP_CIPHER *type, unsigned char *plaintext);

int _encrypt(unsigned char *plaintext, int plaintext_len, unsigned char *key, unsigned char *iv, const EVP_CIPHER *type, unsigned char *ciphertext)
{
    EVP_CIPHER_CTX *ctx;
    int len;
    int ciphertext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
    {
        handleErrors("_encrypt EVP_CIPHER_CTX_new");
    }

    /* Initialise the encryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits */
    if(1 != EVP_EncryptInit_ex(ctx, type, NULL, key, iv))
    {
        handleErrors("EVP_EncryptInit_ex");
    }

    /* Provide the message to be encrypted, and obtain the encrypted output.
     * EVP_EncryptUpdate can be called multiple times if necessary
     */
    if(1 != EVP_EncryptUpdate(ctx, ciphertext, &len, plaintext, plaintext_len))
    {
        handleErrors("EVP_EncryptUpdate");
    }
    ciphertext_len = len;

    /* Finalise the encryption. Further ciphertext bytes may be written at
     * this stage.
     */
    if(1 != EVP_EncryptFinal_ex(ctx, ciphertext + len, &len))
    {
        handleErrors("EVP_EncryptFinal_ex");
    }
    ciphertext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return ciphertext_len;
}

int _decrypt(unsigned char *ciphertext, int ciphertext_len, unsigned char *key, unsigned char *iv, const EVP_CIPHER *type, unsigned char *plaintext)
{
    EVP_CIPHER_CTX *ctx;
    int len;
    int plaintext_len;

    /* Create and initialise the context */
    if(!(ctx = EVP_CIPHER_CTX_new()))
    {
        handleErrors("_decrypt EVP_CIPHER_CTX_new");
    }

    /* Initialise the decryption operation. IMPORTANT - ensure you use a key
     * and IV size appropriate for your cipher
     * In this example we are using 256 bit AES (i.e. a 256 bit key). The
     * IV size for *most* modes is the same as the block size. For AES this
     * is 128 bits */
    if(1 != EVP_DecryptInit_ex(ctx, type, NULL, key, iv))
    {
        handleErrors("EVP_DecryptInit_ex");
    }

    /* Provide the message to be decrypted, and obtain the plaintext output.
     * EVP_DecryptUpdate can be called multiple times if necessary
     */
    if(1 != EVP_DecryptUpdate(ctx, plaintext, &len, ciphertext, ciphertext_len))
    {
        handleErrors("EVP_DecryptUpdate");
    }
    plaintext_len = len;

    /* Finalise the decryption. Further plaintext bytes may be written at
     * this stage.
     */
    if(1 != EVP_DecryptFinal_ex(ctx, plaintext + len, &len))
    {
        handleErrors("EVP_DecryptFinal_ex");
    }
    plaintext_len += len;

    /* Clean up */
    EVP_CIPHER_CTX_free(ctx);

    return plaintext_len;
}

int aes_encrypt(unsigned char *from, int from_len, unsigned char *to, int mode, int flg)
{
    int ret = -1;
    unsigned char *to_result;
    int rlen  = from_len;
    unsigned char *de_result = (unsigned char *)malloc((rlen * 3) / 4 + 1);
    if (NULL == de_result)
    {
        handleErrors("alloc de_result");
    }
    base64_decode((const char*)from, de_result, &rlen);
    from_len = rlen;
    to_result = (unsigned char*)malloc((from_len / AES_BLOCK_SIZE + 1) * AES_BLOCK_SIZE);
    if (NULL == to_result)
    {
        free(de_result);
        handleErrors("alloc to_result");
    }
    switch (mode)
    {
    case AES_256_CBC:
        if (flg == AES_ENCRYPT) ret = _encrypt(de_result, from_len, key256, ive128, EVP_aes_256_cbc(), to_result);
        else if (flg == AES_DECRYPT) ret = _decrypt(de_result, from_len, key256, ive128, EVP_aes_256_cbc(), to_result);
        break;
    default:
        break;
    }
    free(de_result);
    if (ret == -1)
    {
        free(to_result);
        handleErrors("_encrypt _decrypt");
    }
    base64_encode((const unsigned char*)to_result, ret, (char*)to);
    free(to_result);
    return strlen((const char*)to);
}

int EnAES256(unsigned char *plaintext, int plaintext_len, unsigned char *ciphertext, int mode)
{
    return aes_encrypt(plaintext, plaintext_len, ciphertext, mode, AES_ENCRYPT);
}

int DeAES256(unsigned char *ciphertext, int ciphertext_len, unsigned char *plaintext, int mode)
{
    return aes_encrypt(ciphertext, ciphertext_len, plaintext, mode, AES_DECRYPT);
}